var searchData=
[
  ['integrate_5ffunctor',['integrate_functor',['../structintegrate__functor.html',1,'']]]
];
