var searchData=
[
  ['operator_28_29',['operator()',['../structintegrate__functor.html#a772e86ead8690332beb50911e4448f81',1,'integrate_functor']]]
];
