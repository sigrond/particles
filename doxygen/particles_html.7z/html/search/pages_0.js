var searchData=
[
  ['cząstki',['Cząstki',['../index.html',1,'']]]
];
