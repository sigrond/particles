var searchData=
[
  ['ox',['ox',['../particles_8cpp.html#afef635ed3c73fc60d8faf6dd610c4298',1,'particles.cpp']]],
  ['oy',['oy',['../particles_8cpp.html#a791e26888be6777cd5c5d0c736a06821',1,'particles.cpp']]]
];
