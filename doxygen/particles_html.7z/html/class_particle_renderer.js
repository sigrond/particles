var class_particle_renderer =
[
    [ "DisplayMode", "class_particle_renderer.html#a7b691afffd1abe415cb0ce17fd26f3d5", [
      [ "PARTICLE_POINTS", "class_particle_renderer.html#a7b691afffd1abe415cb0ce17fd26f3d5a76d84afc3ec5c09bff035fe798dacbbe", null ],
      [ "PARTICLE_SPHERES", "class_particle_renderer.html#a7b691afffd1abe415cb0ce17fd26f3d5acc641adfb37c1a267e9f91d128094111", null ],
      [ "PARTICLE_NUM_MODES", "class_particle_renderer.html#a7b691afffd1abe415cb0ce17fd26f3d5a251fd7044eb27c60bf1eaa1e64a2d2dc", null ]
    ] ],
    [ "ParticleRenderer", "class_particle_renderer.html#a1718484686c2e6db488cc88c433d03cc", null ],
    [ "~ParticleRenderer", "class_particle_renderer.html#a281be31ad850fead012460fb6675db98", null ],
    [ "_compileProgram", "class_particle_renderer.html#a3a7af352d38734b6bfa425e3b207d60b", null ],
    [ "_drawPoints", "class_particle_renderer.html#a2683c43c010bff7973a977c1953f2bd6", null ],
    [ "_initGL", "class_particle_renderer.html#ac75c7f73a0014333305b174b8863a46b", null ],
    [ "display", "class_particle_renderer.html#a80b2f52dc28bb3abbde021f7fe96f8ff", null ],
    [ "displayGrid", "class_particle_renderer.html#a0e0a5d323acf55087911ea77a2a3eafa", null ],
    [ "setColorBuffer", "class_particle_renderer.html#af16e23ebcee20753d86d24e4e5e32c7c", null ],
    [ "setFOV", "class_particle_renderer.html#ad6da663d3073401a776edb8dc6cf4d5f", null ],
    [ "setParticleRadius", "class_particle_renderer.html#aff09822b565b6953fc83c88bda7fa378", null ],
    [ "setPointSize", "class_particle_renderer.html#a68df35cdf53ad987aa6d8360b3531627", null ],
    [ "setPositions", "class_particle_renderer.html#adb3204e8af23a65b05b1aca7f43f0430", null ],
    [ "setVertexBuffer", "class_particle_renderer.html#a9c0d44ba7666ab432004a5df4cbb2b59", null ],
    [ "setWindowSize", "class_particle_renderer.html#ad84b464475e5ebd42cfed6e2e91e7247", null ],
    [ "m_colorVBO", "class_particle_renderer.html#a7dcaa73a41c598207974432206b423b5", null ],
    [ "m_fov", "class_particle_renderer.html#a0aed003bd557a3c32ca7d2ca89fc59f7", null ],
    [ "m_numParticles", "class_particle_renderer.html#af885fdb5e6da925209dfd960f66b5fd8", null ],
    [ "m_particleRadius", "class_particle_renderer.html#aab5ee3cd769a64c45dc9714aabdb0ee2", null ],
    [ "m_pointSize", "class_particle_renderer.html#a1ca13e546c937cb546c0da19fa853b34", null ],
    [ "m_pos", "class_particle_renderer.html#a1d74720edb5c3a13edcdd176ac0d84c7", null ],
    [ "m_program", "class_particle_renderer.html#ab8f0dd1a6e0f4401012bd46ae8940648", null ],
    [ "m_vbo", "class_particle_renderer.html#a7549feaa0982abbc44c9fe73f2eb251f", null ],
    [ "m_window_h", "class_particle_renderer.html#af34b1e93f6a7f22774a6473c52027d77", null ],
    [ "m_window_w", "class_particle_renderer.html#aa71b7eba5d5665a086b7ba80adddf19b", null ]
];